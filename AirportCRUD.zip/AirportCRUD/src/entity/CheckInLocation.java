package entity;

public class CheckInLocation 
{
    private int CheckInLocationID;
    private String StationName;
    
    
    public CheckInLocation(int CheckInLocationID, String StationName)
    {
        this.CheckInLocationID = CheckInLocationID;
        this.StationName = StationName;
    }

    public int getCheckInLocationID() {
        return CheckInLocationID;
    }

    public String getStationName() {
        return StationName;
    }

   
    @Override
    public String toString() {
        return "CheckInLocation{" + "ID=" + CheckInLocationID + ", StationName=" + StationName + ", dateTime=" + '}';
    }
}
