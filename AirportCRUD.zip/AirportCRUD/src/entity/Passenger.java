package entity;

public class Passenger 
{
    private int PassengerID;
    private String firstName;
    private String lastName;
    private String CheckInDateTime;
    private int CheckInLocationID;

    
    public Passenger(int PassengerID, String firstName, String lastName, String CheckInDateTime, int CheckInLocationID)
    {
        this.PassengerID = PassengerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.CheckInDateTime = CheckInDateTime;
        this.CheckInLocationID = CheckInLocationID;
    }

    public int getPassengerID() {
        return PassengerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getCheckInDateTime() {
        return CheckInDateTime;
    }

    public int getCheckInLocationID() {
        return CheckInLocationID;
    }


    @Override
    public String toString() {
        return "Passenger{" + " ID=" + PassengerID + ", firstName=" + firstName + ", lastName=" + lastName + ", CheckInDateTime=" + CheckInDateTime + ", CheckInLocationID=" + CheckInLocationID +"}";
    }
}
